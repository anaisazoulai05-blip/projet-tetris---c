#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h> 

typedef struct piece{ //structure pour les pieces du plateau
    int couleur; 
    char forme;
    char *f;
    struct piece *suiv;
    int numero_plateau;
}Piece;

typedef struct{//chaine simplement chainee circulaire
    Piece *premier;
    Piece *dernier;
    int taille;
}Plateau;

typedef struct piece2{ //structure pour les pieces des listes de couleurs et de formes
    struct piece2 *precedent;
    struct piece2 *suivant;
    char forme;
    int couleur;
    int numero_plateau;
}Piece2; 

typedef struct liste2{ //listes doublement chainees et doublement circulaire
    Piece2 *premier;
    Piece2 *dernier;
    struct liste2 *suivant;
    int taille;
}Liste2;


typedef struct { //liste simplement chainee contenant les listes de formes/couleurs pour y acceder plus facilement
    Liste2 *premier;
    int taille;
}ListedeListe;

Plateau *creer_plateau(){
    Plateau *p=(Plateau*)malloc(sizeof(Plateau));
    if (p==NULL){
        return NULL;
    }
    p->taille=0;//attention c'est bien 0 et pas la taille max sinon le joueur va perdre des le debut avant meme de commencer a jouer
    p->premier=NULL;
    p->dernier=NULL;
    //pas besoin de se soucier tout de suite de la liaison circulaire vu que quand on mettera les peices on assurera a ce moment les liaisons entre le dernier element et le premier
    return p;
}

const char *random_couleur(){/*cette fonction est avec une etoile car le tableau couleur est un tableau de pointeurs vers des chaines de caracteres et donc si on ne met pas le pointeur ca va juste renvoyer le 1er caractere de notre chaine. ex rouge va renvoyer "r"  */
    const char *Couleur[4]={"rouge", "bleu", "jaune", "vert"}; 
    int i=rand()%4;
    return Couleur[i];
}

int ascii_couleur() {
    const char *couleur = random_couleur();
    
    if (strcmp(couleur, "rouge") == 0) {
        return 31;
    }
    if (strcmp(couleur, "bleu") == 0) {
        return 34;
    }
    if (strcmp(couleur, "jaune") == 0) {
        return 33;
    }
    else { // si c est vert
        return 32;
    }
}

int ascii_couleur2(char *couleur){
    if (strcmp(couleur, "rouge") == 0) {
        return 31;
    }
    if (strcmp(couleur, "bleu") == 0) {
        return 34;
    }
    if (strcmp(couleur, "jaune") == 0) {
        return 33;
    }
    else { // si c est vert
        return 32;
    }
}


char random_forme(){
    char Forme[4]={'C','L','T','R'};
    int i=rand()%4;
    return Forme[i];
}

void traduit(Piece *p){
    if (p->forme == 'C'){
        p->f = "■" ;
    }
    else if (p->forme == 'T'){
        p->f = "▲" ;
    }
    else if (p->forme == 'R'){
        p->f = "○" ;
    }
    else {
        p->f = "◆" ;
    }
}

Piece *creer_nouvelle_piece(){
    Piece *piece=(Piece *)malloc(sizeof(Piece));
    if (piece==NULL){
        printf("pas de place");
        return NULL;
    }
    int couleur=ascii_couleur();
    piece->couleur=couleur;
    char forme=random_forme();/*une etoile la peut etre devant random*/
    piece->forme=forme;
    traduit(piece);
    piece->numero_plateau=0;
    piece->suiv=NULL;
    return piece;
}

void affichage_plateau_iteratif(Plateau *p) {
    if (p->premier == NULL) {
        printf("\n");
        printf("             ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        printf("\n");  // Affiche une ligne vide pour un plateau vide
        return;
    }

    Piece *piece = p->premier;
    printf("         ");
    do { // On a trouve joli de le faire avec un do mais ca aurait ete plus simple avec la taille
        int couleur = piece->couleur;
        char *forme = piece->f;
        printf("\033[%dm%s\033[0m ", couleur, forme);
        piece=piece->suiv;
    } while (piece != p->premier);//pour qu on puisse le faire au moins une fois car sinon des la premiere boucle la piece sera egale au premier
    printf("                  ");
    printf("\n");
    printf("      ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");//permet de faire la igne du plateau
    printf("         ");
    printf("                  ");
    printf("\n");
}

void remettre_plateau_en_place(Plateau *p){
    if (p->taille==0){
        return;
    }
    Piece *piece=p->premier;
    for (int i=0; i<p->taille; i++){
        piece->numero_plateau=i;
        piece=piece->suiv;
    }
}

void donner_un_numero(Plateau *p, Piece *piece, char commande){ //donne un numero a une nouvelle piece du plateau
    if (p->taille==0){
        piece->numero_plateau=0;
    }
    else{
        if (commande=='g'){
            remettre_plateau_en_place(p);
        }
        else{
            piece->numero_plateau=p->taille-1; //pcq on a incremente avant de donner le numero donc sinon ca va donner un numero trop grand
        }
    }
}

void Placer_piece(Plateau *p, Piece *nouvelle_piece, char commande) {
    if (p->premier == NULL) {
        /* Si le plateau est vide, on ajuste les pointeurs pour creer une chaine circulaire avec une seule piece a l interieur */
        p->premier = nouvelle_piece;
        p->dernier = nouvelle_piece;
        nouvelle_piece->suiv = nouvelle_piece;
    } else {
        if (commande == 'g') {
            nouvelle_piece->suiv=p->premier;
            p->premier=nouvelle_piece;
            p->dernier->suiv=p->premier;
            }
        else if (commande == 'd') {  
            p->dernier->suiv=nouvelle_piece;
            p->dernier=nouvelle_piece;
            p->dernier->suiv=p->premier;
            }
    }
    ++p->taille;
    donner_un_numero(p, nouvelle_piece, commande);
}

void affichage_piece(Piece *piece) {
    int couleur = piece->couleur;
    char forme = piece->forme;
    printf("\033[%dm%c\033[0m", couleur, forme); //ici sans \033[0m ca va afficher les phrases de la meme couleur que la derniere piece affichee
}




Liste2 *creer_liste(){
    Liste2 *f=(Liste2 *)malloc(sizeof(Liste2));
    if (f==NULL){
        return NULL;
    }
    f->taille=0;
    f->premier=NULL;
    f->dernier=NULL;
    return f;
}

ListedeListe *creer_listedeliste_forme(Liste2 *C, Liste2 *T, Liste2 *R, Liste2 *L){
    ListedeListe *g = (ListedeListe *)malloc(sizeof(ListedeListe));
    if (g==NULL){
        return NULL;
    }
    g->premier = C;
    Liste2 *P = g->premier;
    P->suivant = T;
    P->suivant->suivant = R; 
    P->suivant->suivant->suivant = L;
    g->taille = 4;
    return g;
}

ListedeListe *creer_listedeliste_couleur(Liste2 *rouge, Liste2 *vert, Liste2 *bleu, Liste2 *jaune){
    ListedeListe *g = (ListedeListe *)malloc(sizeof(ListedeListe));
    if (g==NULL){
        return NULL;
    }
    g->premier = rouge;
    Liste2 *P = g->premier;
    P->suivant = vert;
    P->suivant->suivant = bleu;
    P->suivant->suivant->suivant = jaune;
    g->taille = 4;
    return g;
}

void affichage_piece2(Piece2 *piece) {
    int couleur = piece->couleur;
    char forme = piece->forme;
    printf("\033[%dm%c\033[0m", couleur, forme);
}


void affichage_Liste(Liste2 *L){
    if (L->premier == NULL) {
        printf("la liste est vide\n");  // Affiche une ligne vide pour une liste vide
    }

    else{
        
        Piece2 *piece = L->premier;
        do { 
            int couleur = piece->couleur;
            char forme = piece->forme;
            printf("\033[%dm%c\033[0m", couleur, forme);
            piece=piece->suivant;
        } while (piece != L->premier); //pour qu on puisse le faire au moins une fois car sinon des la premiere boucle la piece sera egale au premier

        printf("\n");  // on ajoute une nouvelle ligne a la fin
    }
}

Piece2 *conversion(Piece *piece){ //prend une piece de type Piece et la transofrme en type Piece2
    Piece2 *p = (Piece2 *)malloc(sizeof(Piece2));
    p->couleur = piece ->couleur;
    p->forme = piece ->forme;
    p->numero_plateau=piece->numero_plateau;
    p->suivant =NULL;
    p->precedent = NULL;
    return p;
}

Liste2 *TrouverForme(char forme, ListedeListe *M){ //trouve la forme d une piece en fonction de sa forme et renvoie sa liste correspondante
    Liste2 *P = M->premier; 
    char tab[4] = {'C','T','R','L'};
    for(int i =0;i<4;i++){
        if(forme == tab[i]){
            return P;
        }
        else{
            P=P->suivant;
        }
    }
    return P; // ne rentrera jamais dans ce cas mais c est juste pour ne pas rien renvoyer puisqu il s agit d une non-void fonction
}

Liste2 *TrouverCouleur(int couleur, ListedeListe *N){//trouve la forme d une piece en fonction de sa couleur et renvoie sa liste correspondante
    Liste2 *P = N->premier; 
    int tab[4] = {31,32,34,33};
    for(int i =0;i<4;i++){
        if(couleur == tab[i]){
            return P;
        }
        else{
            P=P->suivant;
        }
    }
    return P; // ne rentrera jamais dans ce cas mais c est juste pour ne pas rien renvoyer puisqu il s agit d une non-void fonction
}

void liaison_forme(Piece *nouvelle_piece, char commande, ListedeListe *M){ //cette fonction permet de lier une piece a sa liste de forme
    Piece2 *pf = conversion(nouvelle_piece);
    Liste2 *P = TrouverForme(pf->forme, M);
    if(P->taille == 0){
        P->premier = pf;
        P->dernier = pf;
        P->dernier->suivant = P->premier;
        P->premier->precedent = P->dernier;
        P->taille++;
    }

    else if(commande=='g'){
        P->premier->precedent = pf;
        pf->suivant = P->premier;
        pf->precedent = P->dernier;
        P->dernier->suivant = pf;
        P->premier = pf;
        P->taille++;       
    }        
            
    else if(commande == 'd'){
        P->dernier->suivant = pf;
        pf->precedent = P->dernier;
        pf->suivant = P->premier;
        P->premier->precedent = pf;
        P->dernier = pf;
        P->taille++;
    }
}

void liaison_couleur(Piece *nouvelle_piece, char commande, ListedeListe *N){//cette fonction permet de lier une piece a sa liste de couleur
    Piece2 *pf = conversion(nouvelle_piece);
    Liste2 *P = TrouverCouleur(pf->couleur, N);
    if(P->taille == 0){
        P->premier = pf;
        P->dernier = pf;
        P->dernier->suivant = P->premier;
        P->premier->precedent = P->dernier;
        P->taille++;
    }

    else if(commande=='g'){
        P->premier->precedent = pf;
        pf->suivant = P->premier;
        pf->precedent = P->dernier;
        P->dernier->suivant = pf;
        P->premier = pf;
        P->taille++;
    }
            
    else if(commande == 'd'){
        P->dernier->suivant = pf;
        pf->precedent = P->dernier;
        pf->suivant = P->premier;
        P->premier->precedent = pf;
        P->dernier = pf;
        P->taille++;
    }
}

void brisage_de_liens_forme(Piece *piece, char commande, ListedeListe *M){// permet d'isoler une piece en cassant ses liens avec les pieces de sa sous liste forme 
    Liste2 *P = TrouverForme(piece->forme, M);
    
    if (P == NULL || P->premier == NULL){
        return;
    } 

    if (commande == 'g') {   
        if (P->premier == P->dernier) {
            free(P->premier);
            P->premier = P->dernier = NULL;
        } 
        else {
            Piece2 *tmp=P->premier;
            P->premier = P->premier->suivant;
            P->premier->precedent = P->dernier;
            P->dernier->suivant = P->premier;
            free(tmp);
        }
    } 
    else {
        if (P->dernier == P->premier) {
            free(P->premier);
            P->premier = P->dernier = NULL;
        } 
        else {
            Piece2 *tmp=P->dernier;
            P->dernier = P->dernier->precedent;
            P->dernier->suivant = P->premier;
            P->premier->precedent = P->dernier;
            free(tmp);
        }
    }
    P->taille--;
    // affichage_Liste(P); nous a permis d observer si les brisements de liens se faisaeint correctement
}

void brisage_de_liens_couleur(Piece *piece, char commande, ListedeListe *N){// permet d'isoler une piece en cassant ses liens avec les pieces de sa sous liste couleur
    Liste2 *P = TrouverCouleur(piece->couleur, N);
    if (P == NULL || P->premier == NULL) {
        return;
    }

   
    if (P->premier == P->dernier) {
        free(P->premier);
        P->premier = P->dernier = NULL;
    } 
    else if (commande == 'g') {   
        Piece2 *tmp=P->premier;
        P->premier = P->premier->suivant;
        P->premier->precedent = P->dernier;
        P->dernier->suivant = P->premier;
        free(tmp);
    } 
    else if (commande == 'd'){
        Piece2 *tmp=P->dernier;
        P->dernier = P->dernier->precedent;
        P->dernier->suivant = P->premier;
        P->premier->precedent = P->dernier;
        free(tmp);
    }
    P->taille--;
    // affichage_Liste(P); nous a permis d observer si les brisements de liens se faisaeint correctement
}

void remettre_liste_forme_en_place(Plateau *p, ListedeListe *M){ //permet de redonner aux pieces des listes de formes le bon numero de plateau associe apres avoir remis le plateau en place
    Liste2 *L=M->premier;
    for (int i=0; i<4; i++){
        if (L->taille!=0){
            Piece *piece=p->premier;
            Piece2* t= L->premier;
            for (int j=0; j<p->taille; j++){
                if (piece->forme==t->forme){
                    t->numero_plateau=piece->numero_plateau;
                    t=t->suivant;
                }
                piece=piece->suiv;
            }
        }
        L=L->suivant;
    }
}

void remettre_liste_couleur_en_place(Plateau *p, ListedeListe *N){//permet de redonner aux pieces des listes de couleurs le bon numero de plateau associe apres avoir remis le plateau en place
    Liste2 *L=N->premier;
    for (int i=0; i<4; i++){
        if (L->taille!=0){
            Piece *piece=p->premier;
            Piece2* t= L->premier;
            for (int j=0; j<p->taille; j++){
                if (piece->couleur==t->couleur){
                    t->numero_plateau=piece->numero_plateau;
                    t=t->suivant;
                }
                piece=piece->suiv;
            }
        }
        L=L->suivant;
    }
}

int explosion(Plateau *p, char commande, ListedeListe *M, ListedeListe *N){ //explose les trois pieces a gauche ou a droite s il y a explosion et libere la memoire allouee
    int res = 0;
    if (commande == 'g') {
        Piece *p1 = p->premier;
        Piece *p2 = p1->suiv;
        Piece *p3 = p2->suiv;
        if (((p1->forme == p2->forme) && (p2->forme == p3->forme))||((p1->couleur == p2->couleur) && (p2->couleur == p3->couleur))){
            if (p->taille == 3){
                p->premier= NULL;
                p->dernier = NULL;
                p->taille = 0;
            }
            else {
                Piece *p4 = p3->suiv;
                p->premier = p4;
                p->dernier->suiv=p4;
                p->taille -= 3;
            }
            res = 1;
        }
    
        if (res==1){
            brisage_de_liens_forme(p1, commande, M);
            brisage_de_liens_couleur(p1, commande, N);
            free(p1);
            
            brisage_de_liens_forme(p2, commande, M);
            brisage_de_liens_couleur(p2, commande, N);
            free(p2);
            
            brisage_de_liens_forme(p3, commande, M);
            brisage_de_liens_couleur(p3, commande, N);
            free(p3);
        }
        remettre_plateau_en_place(p);
        remettre_liste_forme_en_place(p, M);
        remettre_liste_couleur_en_place(p, N);
        return res;
    
    }
    
    else { 
        int i=0;
        Piece *p1=p->premier;
        Piece *p4=NULL;
        while(i<p->taille-3){
            p4=p1;
            p1=p1->suiv;
            i++;
        }
        Piece *p2 = p1->suiv;
        Piece *p3 = p2->suiv;
        
        
        
        if (((p1->forme == p2->forme) && (p2->forme == p3->forme))|| ((p1->couleur == p2->couleur) && (p2->couleur == p3->couleur))){
            if (p->taille == 3){
                p->premier= NULL;
                p->dernier = NULL;
                p->taille = 0;
            }
            else{
                p->dernier=p4;
                p->dernier->suiv=p->premier;
                p->taille -= 3;
            }
            res = 1;
        }
    
        if(res == 1){   
            brisage_de_liens_forme(p3, commande, M);
            brisage_de_liens_couleur(p3, commande, N);
            free(p3);
            
            brisage_de_liens_forme(p2, commande, M);
            brisage_de_liens_couleur(p2, commande, N);
            free(p2);
            
            brisage_de_liens_forme(p1, commande, M);
            brisage_de_liens_couleur(p1, commande, N);
            free(p1);
        }
        return res;
    }
} 


void decalage_forme(char D, ListedeListe *M, Plateau *p) { //cette fonction permet de faire les decalages tout d abord sur la liste de forme en question puis de faire les modifications necesaires sur les couleurs du plateau puisque les formes ne sont pas modifiees
    Liste2 *l1 = TrouverForme(D, M);
    Piece2 *q = l1->premier;
    l1->premier = l1->premier->suivant;
    l1->dernier = q;
    l1->dernier->suivant = l1->premier; // les liens sont conserves mais on doit changer le pointeur du dernier sur le nouveau premier

    // ici on va remettre les couleurs a la bonne place sur le plateau
    Piece *p1 = p->premier;
    Piece2 *f = l1->premier; 
    for (int i = 0; i < p->taille; i++) {
        if (p1->forme == D) {
            p1->couleur = f->couleur;
            f = f->suivant;        
        }
        p1 = p1->suiv; 
    }
    remettre_liste_forme_en_place(p, M); //en realite, pas besoin de faire pour toutes les formes seulement celle sur laquelle on vient de faire le decalage mais il aurait fallu refaire une fonction
    /*printf("\nles listes apres decalage forme sont:\n");
    Liste2 *Q=M->premier;
    for (int i=0; i<4; i++){
        affichage_Liste(Q);
        Q=Q->suivant;
    }*/
}

void stabiliteF(ListedeListe *M, Plateau *p){ //permet de remettre en place toutes les listes de couleurs apres un decalage forme 
    Liste2 *L=M->premier;
    for(int i = 0; i<4; i++){
        if (L->taille>1){
            Piece2 *t=L->premier;
            Piece *q = p->premier;
            for(int j=0; j<p->taille; j++){
                if(t->forme!=q->forme){
                    q=q->suiv;
                }
                else if (t->forme==q->forme && t->couleur!=q->couleur){
                    t->couleur=q->couleur;
                    t=t->suivant;
                    q=q->suiv;
                }
                else if (t->forme==q->forme && t->couleur==q->couleur){
                    t=t->suivant;
                    q=q->suiv;
                }
            }
        }
        /*else{
            printf("aucune stabilite a faire vu que la liste est vide\n");
        }*/
        L=L->suivant;
    }
    remettre_liste_forme_en_place(p, M);
    /*printf("\nLes listes de formes apres stabilite forme sont:\n");
    Liste2 *Q=M->premier;
    for (int i=0; i<4; i++){
        affichage_Liste(Q);
        Q=Q->suivant;
    }*/
}

void decalage_couleur(int D, ListedeListe *N, Plateau *p){//cette fonction permet de faire les decalages tout d abord sur la liste de couleur en question puis de faire les modifications necesaires sur les formes du plateau puisque les couleurs ne sont pas modifiees
    Liste2 *l1 = TrouverCouleur(D, N);
    
    Piece2 *q = l1->premier;
    l1->premier = l1->premier->suivant;
    l1->dernier = q;
    l1->dernier->suivant = l1->premier; 

    // ici on va remettre les formes a la bonne place sur le plateau
    Piece *p1 = p->premier;
    Piece2 *c = l1->premier; 
    for (int i = 0; i < p->taille; i++) {
        if (p1->couleur == D) {
            p1->forme = c->forme;
            c = c->suivant;
        }
        p1 = p1->suiv; 
    }
    remettre_liste_couleur_en_place(p,N);//en realite pas besoin de faire pour toutes les couleurs seulement celle sur laquelle on vient de faire le decalage mais il aurait fallu refaire une fonction
    /*printf("\nles listes apres decalage couleur sont:\n");
    Liste2 *Q=N->premier;
    for (int i=0; i<4; i++){
        affichage_Liste(Q);
        Q=Q->suivant;
    }*/
}

    
void stabiliteC(ListedeListe *N, Plateau *p){//permet de remettre en place toutes les listes de formes apres un decalage couleur
    Liste2 *L=N->premier;
    for(int i = 0; i<4; i++){
        if (L->taille>1){
            Piece2 *t=L->premier;
            Piece *q = p->premier;
            for(int j=0; j<p->taille; j++){
                if(t->couleur!=q->couleur){
                    q=q->suiv;
                }
                else if (t->couleur==q->couleur && t->forme!=q->forme){
                    t->forme=q->forme;
                    t=t->suivant;
                    q=q->suiv;
                }
                else if (t->couleur==q->couleur && t->forme==q->forme){
                    t=t->suivant;
                    q=q->suiv;
                }
            }
        }
        /*else{
            printf("aucune stabilité a faire vu qeu la liste est vide\n");
        }*/
        L=L->suivant;
    }
    remettre_liste_couleur_en_place(p,N);
    /*printf("\nles listes apres stabilite couleur sont:\n");
    Liste2 *Q=N->premier;
    for (int i=0; i<4; i++){
        affichage_Liste(Q);
        Q=Q->suivant;
    }*/
    
}

int eligibilite_forme(Plateau *p, char Tab1[4], char Tab[4]){// permet de trouver toutes les formes sur lesquelles on peut faire un decalage
    int a = 0;
    for(int i = 0; i<4; i++){
        int cpt = 0;
        Piece *piece = p->premier;
        for (int j=0; j<p->taille; j++){
            if(piece->forme == Tab1[i]){
                cpt++;
            }
            piece=piece->suiv; 
        }
    
        if (cpt>=2){
            Tab[a] = Tab1[i];
            a++;
        }
    }
    // printf("a=%d\n", a);
    return a;
}

int eligibilite_couleur(Plateau *p, int Tab1[], char *Tab2[], char *Tab3[]){// permet de trouver toutes les couleurs sur lesquelles on peut faire un decalage
    int b = 0;
    for (int i=0; i<4; i++){
        int cpt = 0;
        Piece *piece = p->premier;
        for (int j=0; j<p->taille; j++){
            if(piece->couleur == Tab1[i]){
                cpt++;
            }
            piece=piece->suiv; 
    
        } 
        if (cpt>=2){
            Tab3[b] = malloc(strlen(Tab2[i]) + 1);
            strcpy(Tab3[b],Tab2[i]);
            b++;
        }
    }
    // printf("b=%d\n", b);
    return b;
}

void eligible2(Plateau *p, ListedeListe *M, ListedeListe *N){ //affiche toutes les formes et couleurs eligibles et demande a l utilisateur d en saisir une parmi toutes s'il y a decalage
    char Forme[4]={'C','L','T','R'};
    char Forme_eligible[5] = {'A', 'A', 'A', 'A', 'A'};
    int Couleur[4] = {31,34,33,32};
    char *Couleur_eligible[5] = {"marron","marron","marron","marron", "marron"};
    char *couleurlettre[4] = {"rouge", "bleu", "jaune", "vert"};
    
    int a=eligibilite_forme(p, Forme, Forme_eligible);
    int b=eligibilite_couleur(p, Couleur, couleurlettre, Couleur_eligible);

    if (a==0){
        printf("Pas de decalage de formes possible.\n");
    }
    else {
        printf("Il est possible de decaler les pieces de formes : ");
        for (int j = 0;Forme_eligible[j] != 'A' ;j++){
            printf("%c, ", Forme_eligible[j]);
        }
    }

    if (b==0){
        printf("Pas de decalage de couleur possible.\n");
    }
    else{  
        int j = 0;
        printf("Il est possible de decaler les formes de couleur : ");
        while(strcmp(Couleur_eligible[j],"marron") != 0){
            printf("%s, ", Couleur_eligible[j]);
            j++;
        }
        printf("\n");
    }

    if ((a!=0) && (b!=0)){
        printf("Voulez vous modifier la forme ou la couleur? appuyez sur 1 pour les formes et 2 pour les couleurs: \n");
        int d=1;
        while (d!=0){
            int res;
            scanf("%d", &res);
            while (res != 1 && res != 2) {
                printf("Vous devez entrer un nombre entier (1 ou 2). Veuillez recommencer:\n");
                while (getchar() != '\n'); //permet de vider le tampon
                break;
            }
            if (res==1){
                int c = 0;
                while (c==0){
                    char reponse;
                    printf("Choisis la forme :");
                    scanf(" %c", &reponse);
                    int a = 0; 
                    for (int k = 0; k<=3 ; k++){
                        if (Forme_eligible[k] == reponse){
                            decalage_forme(Forme_eligible[k],M,p);
                            stabiliteC(N,p);
                            c = 1;
                            a = 1;
                            break;
                        }    
                    }
                    if(a==0){
                        printf("ce que vous avez saisi ne se trouve pas dans les decalages possibles veuillez recommencer:\n ");
                    }
                }
                d=0;
            }
            if (res==2){
                int c = 0;
                while (c==0){
                    char reponse[6];
                    printf("Choisis la couleur :");
                    scanf(" %s", reponse);
                    int u = 0; 
                    for (int k = 0; k<=3 ; k++){
                        if (strcmp(Couleur_eligible[k],reponse)==0){
                            int D=ascii_couleur2(Couleur_eligible[k]);
                            decalage_couleur(D,N,p);
                            stabiliteF(M, p);
                            c = 1;
                            u = 1;
                            break;
                        }
                    }
                    if(u==0){
                        printf("ce que vous avez saisi ne se trouve pas dans les decalages possibles veuillez recommencer:\n ");
                    }
                    
                }
                d=0;
            }
        }
    }
        

    else if (a!=0){
        printf("choisissez une forme a modifier\n");
        int c = 0;
        while (c==0){
            char reponse;
            scanf(" %c", &reponse);
            for (int k = 0; k<=3 ; k++){
                if (Forme_eligible[k] == reponse){
                    decalage_forme(Forme_eligible[k],M,p);
                    stabiliteC(N,p);
                    c = 1;
                    break;
                }
            }
        }
    }

    else if (b!=0){
        printf("choisissez une couleur a modifier");
        int c = 0;
        while (c==0){
            char reponse[6];
            scanf(" %s", reponse);
            for (int k = 0; k<=3 ; k++){
                if (strcmp(Couleur_eligible[k],reponse)==0){
                    int D=ascii_couleur2(Couleur_eligible[k]);
                    decalage_couleur(D,N,p);
                    stabiliteF(M,p);
                    c = 1;
                    break;
                }
            }
        }
    }
    for( int i= 0;i<b;i++){
    	free(Couleur_eligible[i]);
    }
    return;
}

void brisage_de_liens_decalage_forme(Plateau *p, Piece *piece, ListedeListe *M){ //brise les liens d une piece avec sa liste de forme apres un decalage provoquant une explosion et libere la memoire de cette piece
    Piece2*pf=conversion(piece);
    Liste2 *P = TrouverForme(pf->forme, M);

    if (P == NULL || P->premier == NULL){
        free(pf);
        return;
    } 

    if (P->premier == P->dernier) {
        free(P->premier);
        P->premier = P->dernier = NULL;
    }

    else if (pf->numero_plateau==P->premier->numero_plateau){
        if (P->taille==2){
            Piece2 *tmp=P->premier;
            P->premier=P->dernier;
            P->dernier->suivant=P->premier;
            P->premier->precedent=P->dernier;
            free(tmp);
        }
        else{
            Piece2 *tmp=P->premier;
            P->premier=P->premier->suivant;
            P->premier->precedent=P->dernier;
            P->dernier->suivant=P->premier;
            free(tmp);
        }
    }

    else{
        Piece2 *p1=P->premier;
        Piece2 *p2;
        while (p1->numero_plateau!=pf->numero_plateau){
            p2=p1;
            p1=p1->suivant;
        }
        if (P->taille==2){
            Piece2 *tmp=P->dernier;
            P->dernier=P->premier;
            P->premier->precedent=P->dernier;
            P->dernier->suivant=P->dernier;
            free(tmp);
        }
        else if (p1==P->dernier){
            Piece2 *tmp=P->dernier;
            P->dernier=p2;
            P->dernier->suivant=P->premier;
            P->premier->precedent=P->dernier;
            free(tmp);
        }
        else{
            Piece2 *tmp=p1;
            Piece2 *p3=p1->suivant;
            p2->suivant=p3;
            p3->precedent=p2;
            free(tmp);
        }
        
    }

    P->taille--;
    free(pf);
    //affichage_Liste(P);
}

void brisage_de_liens_decalage_couleur(Plateau *p, Piece *piece, ListedeListe *N){//brise les liens d une piece avec sa liste de couleur apres un decalage provoquant une explosion et libere la memoire de cette piece
    Piece2 *pf=conversion(piece);
    Liste2 *P = TrouverCouleur(pf->couleur, N);

    if (P == NULL || P->premier == NULL){
        free(pf);
        return;
    } 

    if (P->premier == P->dernier) {
        free(P->premier);
        P->premier = P->dernier = NULL;
    }

    else if (pf->numero_plateau==P->premier->numero_plateau){
        if (P->taille==2){
            Piece2 *tmp=P->premier;
            P->premier=P->dernier;
            P->dernier->suivant=P->premier;
            P->premier->precedent=P->dernier;
            free(tmp);
        }
        else{
            Piece2 *tmp=P->premier;
            P->premier=P->premier->suivant;
            P->premier->precedent=P->dernier;
            P->dernier->suivant=P->premier;
            free(tmp);
        }
    }

    else{
        Piece2 *p1=P->premier;
        Piece2 *p2;
        while (p1->numero_plateau!=pf->numero_plateau){
            p2=p1;
            p1=p1->suivant;
        }
        if (P->taille==2){
            Piece2 *tmp=P->dernier;
            P->dernier=P->premier;
            P->premier->precedent=P->dernier;
            P->dernier->suivant=P->dernier;
            free(tmp);
        }
        else if (p1==P->dernier){
            Piece2 *tmp=P->dernier;
            P->dernier=p2;
            P->dernier->suivant=P->premier;
            P->premier->precedent=P->dernier;
            free(tmp);
        }
        else{
            Piece2 *tmp=p1;
            Piece2 *p3=p1->suivant;
            p2->suivant=p3;
            p3->precedent=p2;
            free(tmp);
        }
    }
    
    P->taille--;
    free(pf);
    // affichage_Liste(P);
}


void explosion_super_decalage_forme(Plateau *P, Piece *p, int cpt, ListedeListe *M, ListedeListe *N, int *nb) {// fonction recursive qui permet de trouver les pieces ayant la meme forme de façon consecutive et de reverifier a chaque explosion s'il y en a une nouvelle par rapport aux nouveaux liens entre les pieces du plateau
    Piece *p1 = p->suiv;
    if (p == NULL || P->taille < 3 || p1 == P->premier) {
        return;
    }

    Piece *p2 = p1->suiv;
    Piece *p3 = p2->suiv;
    

    if (p3 == P->premier) {
        // printf("plus d'explosion possible\n");
        return;
    }

    if (p->forme == p1->forme && p1->forme == p2->forme) {
        int a=0;
        char c;
        *nb+=100;

        brisage_de_liens_decalage_forme(P,p,M);
        brisage_de_liens_decalage_couleur(P,p,N);
        free(p);
        brisage_de_liens_decalage_forme(P,p1,M);
        brisage_de_liens_decalage_couleur(P,p1,N);
        free(p1);
        brisage_de_liens_decalage_forme(P,p2,M);
        brisage_de_liens_decalage_couleur(P,p2,N);
        Piece *p3 = p2->suiv;
        c=p2->forme;
        free(p2);
        while (p3->forme == c && p3 != P->premier) {
            brisage_de_liens_decalage_forme(P,p3,M);
            brisage_de_liens_decalage_couleur(P,p3,N);
            Piece *p4=p3->suiv;
            free(p3);
            p3 = p4;
            a++;
            *nb+=10;
            
        }
        P->premier = p3;
        P->dernier->suiv = p3;
        P->taille -= (a + 3);
        remettre_plateau_en_place(P);
        remettre_liste_forme_en_place(P, M);
        remettre_liste_couleur_en_place(P, N);
        explosion_super_decalage_forme(P, P->premier, 0, M, N, nb);
    } 
    else if(p1->forme == p2->forme && p2->forme == p3->forme) {
        int a=0;
        char c;
        *nb+=100;

        brisage_de_liens_decalage_forme(P,p1,M);
        brisage_de_liens_decalage_couleur(P,p1,N);
        free(p1);
        brisage_de_liens_decalage_forme(P,p2,M);
        brisage_de_liens_decalage_couleur(P,p2,N);
        free(p2);
        brisage_de_liens_decalage_forme(P,p3,M);
        brisage_de_liens_decalage_couleur(P,p3,N);
        Piece *p4=p3->suiv;
        c=p3->forme;
        free(p3);
        while (p4->forme == c && p4 != P->premier) {
            brisage_de_liens_decalage_forme(P,p4,M);
            brisage_de_liens_decalage_couleur(P,p4,N);
            Piece *p5=p4->suiv;
            free(p4);
            p4 = p5;
            a++; 
            *nb+=10;
        }
        p->suiv = p4;
        if(cpt + a + 4 == P->taille){
            P->dernier = p;
        }
        P->taille -= (a + 3);
        remettre_plateau_en_place(P);
        remettre_liste_forme_en_place(P, M);
        remettre_liste_couleur_en_place(P, N);
        explosion_super_decalage_forme(P, P->premier, 0, M, N, nb);
    } 
    else {
        explosion_super_decalage_forme(P, p->suiv, cpt + 1, M, N, nb);
    }
}

void explosion_super_decalage_couleur(Plateau *P, Piece *p, int cpt, ListedeListe *M, ListedeListe *N, int *nb){ // fonction recursive qui permet de trouver les pieces ayant la meme couleur de facon consecutive et de reverifier a chaque explosion s'il y en a une nouvelle par rapport aux nouveaux liens entre les pieces du plateau
    Piece *p1 = p->suiv;
    if (p == NULL || P->taille < 3 || p1 == P->premier) {
        return;
    }

    Piece *p2 = p1->suiv;
    Piece *p3 = p2->suiv;
    

    if (p3 == P->premier) {
        // printf("plus d'explosion possible\n");
        return;
    }

    if (p->couleur == p1->couleur && p1->couleur == p2->couleur) {
        int a=0;
        int c=0;
        *nb+=100;

        brisage_de_liens_decalage_couleur(P,p,N);
        brisage_de_liens_decalage_forme(P,p,M);
        free(p);

        brisage_de_liens_decalage_couleur(P,p1,N);
        brisage_de_liens_decalage_forme(P,p1,M);
        free(p1);

        brisage_de_liens_decalage_couleur(P,p2,N);
        brisage_de_liens_decalage_forme(P,p2,M);
        
        Piece *p3 = p2->suiv;
        c=p2->couleur;
        free(p2);
        while (p3->couleur == c && p3 != P->premier) {
            brisage_de_liens_decalage_couleur(P,p3,N);
            brisage_de_liens_decalage_forme(P,p3,M);
            Piece *p4=p3->suiv;
            free(p3);
            p3 = p4;
            a++;
            *nb+=10;
            
        }
        P->premier = p3;
        P->dernier->suiv = p3;
        P->taille -= (a + 3);
        remettre_plateau_en_place(P);
        remettre_liste_forme_en_place(P, M);
        remettre_liste_couleur_en_place(P, N);
        explosion_super_decalage_couleur(P, P->premier, 0, M, N, nb);
    } 
    else if(p1->couleur == p2->couleur && p2->couleur == p3->couleur) {
        int a=0;
        int c=0;
        *nb+=100;

        brisage_de_liens_decalage_couleur(P,p1,N);
        brisage_de_liens_decalage_forme(P,p1,M);
        free(p1);
        
        brisage_de_liens_decalage_couleur(P,p2,N);
        brisage_de_liens_decalage_forme(P,p2,M);
        free(p2);

        brisage_de_liens_decalage_couleur(P,p3,N);
        brisage_de_liens_decalage_forme(P,p3,M);
        Piece *p4=p3->suiv;
        c=p3->couleur;
        free(p3);
        while (p4->couleur == c && p4 != P->premier) {
            brisage_de_liens_decalage_couleur(P,p4,N);
            brisage_de_liens_decalage_forme(P,p4,M);
            Piece *p5=p4->suiv;
            free(p4);
            p4 = p5;
            a++;
            *nb+=10;
            
        }
        p->suiv = p4;
        if(cpt + a + 4 == P->taille){
            P->dernier = p;
        }
        P->taille -= (a + 3);
        remettre_plateau_en_place(P);
        remettre_liste_forme_en_place(P, M);
        remettre_liste_couleur_en_place(P, N);
        explosion_super_decalage_couleur(P, P->premier, 0, M, N, nb);
    } 
    else {
        explosion_super_decalage_couleur(P, p->suiv, cpt + 1, M, N, nb);
    }
}

void liberer_plateau(Plateau *p) {
    if (p->dernier != NULL) {
        p->dernier->suiv = NULL; // pour liberer la memoire c est plus facile de rompre le lien circulaire de la chaine
    }

    Piece *piece = p->premier;
    while (piece != NULL) {
        Piece *tmp = piece;
        piece = piece->suiv;
        free(tmp);
    }
    free(p);
}

void liberer_Liste(Liste2 *L) {
    Piece2 *courant = L->premier;
    while (L->taille > 0) {
        Piece2 *tmp = courant->suivant;
        free(courant);
        courant = tmp;
        L->taille--;
    }
    free(L);
}

void liberer_listedeliste(ListedeListe *M) {
    Liste2 *courant = M->premier;
    while (M->taille > 0) {
        Liste2 *tmp = courant->suivant;
        liberer_Liste(courant); 
        courant = tmp;
        M->taille--;
    }
    free(M); 
}

void liberer_tout(Plateau *P, Plateau *Liste_de_5_pieces, ListedeListe *M, ListedeListe *N){
    liberer_plateau(P);
    liberer_plateau(Liste_de_5_pieces);//on rajoute la liberation des cinq pieces affichees 
    liberer_listedeliste(M);
    liberer_listedeliste(N);
}

void Remplir_Tab_score(int score, char nom_joueur[100], const char *nomFichier) { //permet de remplir un fichier contenant les 10 meilleurs scores
    FILE *f = fopen(nomFichier, "r");

    int Tab_score[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    char Tab_nom_joueur[10][100] = {"vide", "vide", "vide", "vide", "vide", "vide", "vide", "vide", "vide", "vide"};

    int ancienscore;
    char nom[100];
    char ligne[100];

    if (f!=NULL){ //on recupere dans deux tableaux differents tous les anciens noms et anciens scores 
        int position = 0;
        while (position < 10 && fgets(ligne, sizeof(ligne), f) != NULL) {
            
            if (sscanf(ligne, "%s %d", nom, &ancienscore) == 2) {
                strcpy(Tab_nom_joueur[position], nom);
                Tab_score[position] = ancienscore;
                position++;
            }
        }
        
        fclose(f);
    }

    int position = 0;
    while (position < 10) { // on remet dans l ordre les scores en fonction du nouveau ainsi que l ordre des noms
        if (Tab_score[position] <= score){
            int a = Tab_score[position];
            Tab_score[position] = score;
            char c[100];
            strcpy(c, Tab_nom_joueur[position]);
            strcpy(Tab_nom_joueur[position], nom_joueur);
            position++;

            while (position < 10) {
                int b = Tab_score[position];
                Tab_score[position] = a;
                a = b;

                char d[100];
                strcpy(d, Tab_nom_joueur[position]);
                strcpy(Tab_nom_joueur[position], c);
                strcpy(c, d);

                position++;
            }
        } 
        else {
            position++;
        }
    }

    FILE *g = fopen(nomFichier, "w"); // on met 'w' pour pouvoir ecrire dans le fichier depuis le debut donc pour ecrase l ancien contenu
    
    for (int i = 0; i < 10; i++) {
        fprintf(g, "%s %d\n", Tab_nom_joueur[i], Tab_score[i]); // on ecrit dans le fichier les nouveaux noms associes aux nouveaux scores dans l ordre. 
    }

    fclose(g);
}

void sauvegarder(Plateau * p, int score, ListedeListe * M, ListedeListe * N, const char *nomFichier){  // permet de sauvegarder la partie dans l etat actuel du jeu et de le stocker dans un fichier
    FILE *f = fopen (nomFichier, "w");
    if (f == NULL){
        printf ("Erreur d'ouverture du fichier\n");
        return;
    }
    
    fprintf(f, "score: %d\n", score);//on sauvegarde le score

    
    if (p->premier != NULL){// on sauvegarde le plateau
        Piece *piece = p->premier;
        do {
            fprintf (f, "Plateau: %d %c\n", piece->couleur, piece->forme);
            piece = piece->suiv;
        }while (piece != p->premier);
    }

    // on sauvegarde les listes des formes
    
    int j=1;
    
    Liste2 *L = M->premier;
    for (int k=0; k<4; k++){
        if (L->taille!=0){
            Piece2 *piece = L->premier;
            do {
                fprintf (f, "LM%d %d %c\n", j, piece->couleur, piece->forme);
                piece = piece->suivant;
            }while (piece != L->premier);
        }
        j++;
        L= L->suivant;
    }

    // on sauvegarde les listes de couleurs
    j=1;

    Liste2 *Q = N->premier;
    for (int k=0; k<4; k++){
        if (Q ->taille!=0){
            Piece2 *piece = Q->premier;
            do {
                fprintf (f, "LN%d %d %c\n", j, piece->couleur, piece->forme);
                piece = piece->suivant;
            }while (piece != Q->premier);
        }
        j++;
        Q= Q->suivant;
    }
    fclose (f);
}

void remplir_liste_forme(ListedeListe *M, Piece *piece){ //permet de remplir les listes de formes apres avoir repris une partie 
   liaison_forme(piece, 'd', M); 
}

void remplir_liste_couleur(ListedeListe *N, Piece *piece){ //permet de remplir les listes de couleur apres avoir repris une partie
   liaison_couleur(piece, 'd', N);
}

void reprendre (Plateau * p, int *score, ListedeListe * M, ListedeListe * N, const char * nomFichier){ //remplit le plateau et les listes de fromes et de couleur et remet egalement le score a jour en parcourant un fichier de sauvegarde 
    FILE *f = fopen(nomFichier, "r");
    if (f == NULL) {
        printf("Aucune partie n'est enregistree en sauvegarde...\n");
        return;
    }

    char ligne[100];
    char type[10];
    int couleur;
    char forme;
    Piece *nouvellePiece;
    
    if (fscanf(f, "score: %d", score)==1){
        printf("Votre ancien score est de : %d\n", *score);
    }

    while (fgets (ligne, sizeof (ligne), f) != NULL){
        if (sscanf (ligne, "%s %d %c", type, &couleur, &forme) == 3){

            nouvellePiece = (Piece *) malloc (sizeof (Piece));
            nouvellePiece->couleur = couleur;
            nouvellePiece->forme = forme;
            traduit(nouvellePiece);
            nouvellePiece->numero_plateau=0;
            
            if (strcmp (type, "Plateau:") == 0){
                
                if (p->taille==0){
                    p->premier = nouvellePiece;
                    p->dernier = nouvellePiece;
                    p->dernier->suiv=p->premier;
                }
                else{
                    p->dernier->suiv = nouvellePiece;
                    p->dernier = nouvellePiece;
                    nouvellePiece->suiv=p->premier;
                }
                p->taille++;
            }
                
            else if (strcmp(type, "LM1") == 0 || strcmp(type, "LM2") == 0 || strcmp(type, "LM3") == 0 || strcmp(type, "LM4") == 0) {
                remplir_liste_forme(M, nouvellePiece);
                free(nouvellePiece);
            } 
            else if (strcmp(type, "LN1") == 0 || strcmp(type, "LN2") == 0 || strcmp(type, "LN3") == 0 || strcmp(type, "LN4") == 0) {
                remplir_liste_couleur(N, nouvellePiece);
                free(nouvellePiece);
            }
        }
    }
    remettre_plateau_en_place(p); 
    remettre_liste_forme_en_place(p, M);
    remettre_liste_couleur_en_place(p,N);  
    fclose(f);
}

void affichage_liste_piece(Plateau *l, Piece *piece, int cpt) {// affiche la liste des 5 pieces aleatoires

    if (cpt==l->taille) {
        printf("|                    ");  // Affiche une ligne vide pour une liste vide
        return;
    }
    affichage_liste_piece(l, piece->suiv, cpt+1);
   
    int couleur = piece->couleur;
    char *forme = piece->f;
    printf("\033[%dm%s\033[0m ", couleur, forme);
    if (cpt == 0){
        printf("                     |");
    }
    
  // Ajoute une nouvelle ligne a la fin
}

void ajout_piece_liste(Piece *p, Plateau *l){ //ajoute une piece dans la liste des 5 et supprime la premiere
    Placer_piece(l, p, 'd');
    if (l->taille==6){
        Piece *tmp=l->premier;
        l->premier=l->premier->suiv;
        l->dernier->suiv=l->premier;
        l->taille--;
        free(tmp);
    }
}

Piece *cloner_piece(const Piece *source) {//permet de recopier les caracteristiques d une piuece a une autre 
    Piece *clone = (Piece *)malloc(sizeof(Piece));
    clone->forme = source->forme;
    clone->f = source->f;
    clone->couleur = source->couleur;
    clone->numero_plateau = source->numero_plateau;
    clone->suiv = NULL;
    return clone;
}

void afficherPlateau(int score, Plateau *liste_de_5_pieces) {
    printf(" ___________________________________________________\n");
    printf("|                                                   |\n");
    printf("|                     Score: %-4d                   |\n", score);
    printf("|___________________________________________________|\n");
    printf("|                                                   |\n");
    printf("|                  Nouvelles pièces :               |\n");
    printf("|                                                   |\n");
    //printf("|");
    affichage_liste_piece(liste_de_5_pieces, liste_de_5_pieces->premier, 0);
    printf("\n");
    //printf("                                                  |\n");
    printf("|___________________________________________________|\n");
}

void accueil(char *nom){
    printf(" __________________________________________________\n");
    printf("|                                                  |\n");
    printf("|                        Téravi                    |\n");
    printf("|__________________________________________________|\n");
    printf("|                                                  |\n");
    printf("|                      Nom joueur :                |\n");
    printf("|                                                  |\n");
    printf("|                    ");
    scanf("%s", nom);
    printf("                                                   |\n");
    printf("|__________________________________________________|\n");
}

int main(){
    char nom[100];
    accueil(nom);

    
    srand(time(NULL));
    Plateau *p=creer_plateau();
    Plateau *liste_de_5_pieces=creer_plateau();
    Liste2 *C=creer_liste();
    Liste2 *R=creer_liste();
    Liste2 *T=creer_liste();
    Liste2 *L=creer_liste();
    Liste2 *rouge=creer_liste();
    Liste2 *vert=creer_liste();
    Liste2 *bleu=creer_liste();
    Liste2 *jaune=creer_liste();
    ListedeListe *M = creer_listedeliste_forme(C, T, R, L);
    ListedeListe *N = creer_listedeliste_couleur(rouge,vert,bleu,jaune);

    Piece *nouvelle_piece=creer_nouvelle_piece();
    ajout_piece_liste(nouvelle_piece, liste_de_5_pieces);
    for (int cpt=0; cpt<4; cpt++){ //pour afficher les 5 pieces
        Piece *prochaine_piece=creer_nouvelle_piece();
        ajout_piece_liste(prochaine_piece, liste_de_5_pieces);
    }

    
    int nb_de_points = 0;
    int reprise = -1;
    printf("Tapez 1 pour reprendre votre ancienne partie (0 pour en recommencer une nouvelle). ");
    scanf(" %d", &reprise);
    if(reprise == 1){
        reprendre(p,&nb_de_points,M,N,"Sauvegarde.txt");
    }
    int i=p->taille;
    while (i < 15){
        
        Piece *nouvelle_piece=cloner_piece(liste_de_5_pieces->premier); 

        afficherPlateau(nb_de_points,liste_de_5_pieces);
        printf(" ___________________________________________________\n");
        printf("|                                                   |\n");
        printf("\n");
        affichage_plateau_iteratif(p);
        printf("|___________________________________________________|\n");
        printf("\n");
        
 
        printf("\nVeuillez saisir g pour gauche, d pour droite, l pour decalage et s pour sauvegarder la partie\n");
        char commande;
        scanf(" %c", &commande);
        
        while ((commande!='g') && (commande!='d') && (commande!='l') && (commande!='s')){
            printf("Attention, vous n'avez pas saisi une commande valide. Veuillez recommencer");
            scanf(" %c", &commande);
        }
        if (commande == 's'){
            sauvegarder(p,nb_de_points,M,N,"Sauvegarde.txt");
            printf("Votre partie a bien ete sauvegardee !\n");
            
            int reponse=0;
            while (reponse==0){
                printf("Si vous voulez stopper votre partie tapez 1 si vous preferez la continuer tapez 2\n");
                scanf("%d", &reponse);
            }
            if (reponse==1){
                free(nouvelle_piece);// on free la piece car elle n a pas eu le temps de rentrer sur le plateau et est independante des autres pieces du plateau
                liberer_tout(p, liste_de_5_pieces, M, N);// on libere ici pour ne pas break et sortir de la boucle while sinon ca va enregistrer son nom dans le top10 alors qu il n a pas termine la partie.
                return 0;
            }
            else{
                afficherPlateau(nb_de_points,liste_de_5_pieces);

                printf("\nVeuillez saisir g pour gauche, d pour droite et l pour decalage\n");
                scanf(" %c", &commande);
                while ((commande!='g') && (commande!='d') && (commande!='l')){
                    printf("Attention, vous n'avez pas saisi une commande valide. Veuillez recommencer");
                    scanf(" %c", &commande);
                }
            }
        }
        if (commande=='l'){
            
            eligible2(p, M, N);
            
            printf(" ___________________________________________________\n");
            printf("|                                                   |\n");
            printf("\n");
            //printf("|              ");
            affichage_plateau_iteratif(p);
            printf("|___________________________________________________|\n");
            //printf("                                 |\n");
            printf("\n");
            
        
            explosion_super_decalage_forme(p, p->premier, 0, M, N, &nb_de_points);
            explosion_super_decalage_couleur(p, p->premier, 0, M, N, &nb_de_points);

            i=p->taille;
            printf(" ___________________________________________________\n");
            printf("|                                                   |\n");
            printf("|                 Nouvelles pièces :                |\n");
            printf("\n");
            //printf("|              ");
            affichage_liste_piece(liste_de_5_pieces, liste_de_5_pieces->premier, 0);
            //affichage_plateau_iteratif(p);
            printf("\n");
            printf("|___________________________________________________|\n");
            //printf("                                 |\n");
            printf("\n");
            

            printf("\nVeuillez saisir g pour gauche, d pour droite et s pour sauvegarder la partie.\n");
            
            scanf(" %c", &commande);
            
            while ((commande!='g') && (commande!='d') && (commande!='s')){
                printf("Attention, vous n'avez pas saisi une commande valide. Veuillez recommencer");
                scanf(" %c", &commande);
            }
            if (commande == 's'){
                sauvegarder(p,nb_de_points,M,N,"Sauvegarde.txt");
                printf("Votre partie a bien ete sauvegardee !\n");
                
                int reponse2=0;
                while (reponse2==0){
                    printf("Si vous voulez stopper votre partie tapez 1 si vous preferez la continuer tapez 2\n");
                    scanf("%d", &reponse2);
                }
                if (reponse2==1){
                    free(nouvelle_piece);// on free la piece car elle n a pas eu le temps de rentrer sur le plateau et est independante des autres pieces du plateau
                    liberer_tout(p, liste_de_5_pieces, M, N);// on libere ici pour ne pas break et sortir de la boucle while sinon ca va enregistrer son nom dans le top10 alors qu il n a pas termine la partie.
                    return 0;
                }
                else{
                    printf("Les 5 prochaines pieces sont:\n");
                    affichage_liste_piece(liste_de_5_pieces, liste_de_5_pieces->premier, 0);
                    printf("\nVeuillez saisir g pour gauche et d pour droite\n");
                    scanf(" %c", &commande);
                    while ((commande!='g') && (commande!='d')){
                        printf("Attention, vous n'avez pas saisi une commande valide. Veuillez recommencer");
                        scanf(" %c", &commande);
                    }
                }
            }
        }
        
        /*la on met un if commande == l il faut verifier si il y a une possibilite de decalage donc on appelle eligible qui appelle elle meme l eligibilite pour les formes egt les couleurs qui les affiche et ensuite qui appelle decalage si le joueur a choisi un decalage*/
        Placer_piece(p, nouvelle_piece, commande);
        
        if (p->taille>0){ 
            liaison_forme(nouvelle_piece, commande, M);
            liaison_couleur(nouvelle_piece, commande , N);
        }
        if (p->taille >= 3){
            int res = explosion(p, commande, M, N);
            if (res>0){
                i -= 3;
                nb_de_points+=30;
            }
        }
        i++;
        Piece *nouvelle_piece2=creer_nouvelle_piece();
        ajout_piece_liste(nouvelle_piece2, liste_de_5_pieces);
    }
    affichage_plateau_iteratif(p);
    Remplir_Tab_score(nb_de_points, nom, "Top10.txt");
    printf("La partie est terminee ! Votre score est de %d. A tres bientot pour une nouvelle partie !\n", nb_de_points);
    liberer_tout(p, liste_de_5_pieces, M, N);
    return 0;
}
